import requests

from lxml.html import fromstring
from itertools import cycle
from utils import *



anaurl = URLCİK
sunucuidsi = SUNUCUİD
webhook = WEBHOOKCUK
token = TOKEN



50 STAR 20 FORKTA GELİR DEVAMI KERANECİLER
