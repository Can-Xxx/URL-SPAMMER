# Url-Spammer

evet sayın ezikler repoya hgniz dc de türemenin biri url çalmaya başlamış işsiz gibi 100 hesapla useragent kullanarak spamlatıyor ve self token tek mantık bu başka birşey yok, python ile yaptığım ilk url spammer botumu paylaşacağım.

50 star
20 fork

