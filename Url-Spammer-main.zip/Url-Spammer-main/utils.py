URLCİK = open("url.txt", "r").read()
SUNUCUİD = open("sunucuid.txt", "r").read()
WEBHOOKCUK = open("webhook.txt", "r").read()
TOKEN = open("token.txt", "r").read()
